import java.util.Random;

public class Laimingas {
    public static void main(String[] args) {
        int ticketNumber = 0;
        int attempts = 0;

        while (true) {
            attempts++;
            ticketNumber = generateRandomTicket();

            if (isLuckyTicket(ticketNumber)) {
                System.out.println("Lucky ticket number: " + ticketNumber);
                System.out.println("Attempts needed: " + attempts);
                break;
            }
        }
    }

    public static int generateRandomTicket() {
        Random random = new Random();
        return 100000 + random.nextInt(900000);
    }

    public static boolean isLuckyTicket(int ticket) {
        String ticketString = String.valueOf(ticket);
        if (ticketString.length() != 6) {
            return false;
        }

        int[] digits = new int[6];
        for (int i = 0; i < 6; i++) {
            digits[i] = Character.getNumericValue(ticketString.charAt(i));
        }

        int firstThreeSum = digits[0] + digits[1] + digits[2];
        int lastThreeSum = digits[3] + digits[4] + digits[5];

        if (firstThreeSum == lastThreeSum) {
            for (int i = 0; i < 6; i++) {
                for (int j = i + 1; j < 6; j++) {
                    if (digits[i] == digits[j]) {
                        return false;
                    }
                }
            }
            return true;
        }
        return false;
    }
}
