import java.util.Random;

public class LaimingasBilietasProc {
    public static void main(String[] args) {
        int bandymai = 0;
        int laimingiBilietai = 0;
        double procentai;

        while (true) {
            int bilietas = generuotiAtsitiktiniBilieta();
            bandymai++;

            if (arLaimingasBilietas(bilietas)) {
                laimingiBilietai++;
                procentai = (double)laimingiBilietai / bandymai * 100;
                System.out.println("Rastas laimingas bilietas: " + bilietas);
                System.out.println("Reikėjo bandymų: " + bandymai);
                System.out.println("Laimingų bilietų procentas: " + procentai + "%");
                break;
            }
        }
    }

    public static int generuotiAtsitiktiniBilieta() {
        Random atsitiktinis = new Random();
        return 100000 + atsitiktinis.nextInt(900000);
    }

    public static boolean arLaimingasBilietas(int bilietas) {
        String bilietoNr = String.valueOf(bilietas);

        if (bilietoNr.length() != 6) {
            return false;
        }

        int[] skaitmenys = new int[6];
        for (int i = 0; i < 6; i++) {
            skaitmenys[i] = Character.getNumericValue(bilietoNr.charAt(i));
        }

        int pirmuTrijuSuma = skaitmenys[0] + skaitmenys[1] + skaitmenys[2];
        int paskutiniuTrijuSuma = skaitmenys[3] + skaitmenys[4] + skaitmenys[5];

        return pirmuTrijuSuma == paskutiniuTrijuSuma && visiSkaitmenysSkirtingi(skaitmenys);
    }

    public static boolean visiSkaitmenysSkirtingi(int[] skaitmenys) {
        for (int i = 0; i < skaitmenys.length; i++) {
            for (int j = i + 1; j < skaitmenys.length; j++) {
                if (skaitmenys[i] == skaitmenys[j]) {
                    return false;
                }
            }
        }
        return true;
    }
}
