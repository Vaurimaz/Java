import java.util.Arrays;
import java.util.Random;

public class LuckyNumberChecker {
    public static boolean isLucky(String number) {
        if (number.length() != 6) {
            return false;
        }

        int firstHalf = 0;
        int secondHalf = 0;
        for (int i = 0; i < 3; i++) {
            firstHalf += Character.getNumericValue(number.charAt(i));
            secondHalf += Character.getNumericValue(number.charAt(i + 3));
        }

        return firstHalf == secondHalf && number.chars().distinct().count() == 6;
    }

    public static String generateNumber() {
        Random random = new Random();
        int[] digits = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
        for (int i = 9; i > 0; i--) {
            int index = random.nextInt(i + 1);
            int temp = digits[index];
            digits[index] = digits[i];
            digits[i] = temp;
        }

        StringBuilder number = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            number.append(digits[i]);
        }

        return number.toString();
    }

    public static void main(String[] args) {
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        System.out.print("Enter a 6-digit number: ");
        String inputNumber = scanner.next();
        scanner.close();

        if (isLucky(inputNumber)) {
            System.out.println("The entered number is lucky!");
            return;
        }

        int tries = 0;
        while (true) {
            tries++;
            String randomNumber = generateNumber();
            if (isLucky(randomNumber)) {
                System.out.println("First lucky number found: " + randomNumber);
                double percentage = 100.0 / tries;
                System.out.printf("It took %d tries to find a lucky number, with a success rate of %.2f%%.%n", tries, percentage);
                break;
            }
        }
    }
}
