import java.text.DecimalFormat;

public class GeoLocation {
    private static final DecimalFormat COORDINATE_FORMAT = new DecimalFormat("0.######");

    private final double lat;
    private final double lon;
    private static int numLocations = 0;

    private GeoLocation(double lat, double lon) {
        this.lat = lat;
        this.lon = lon;
        numLocations++;
    }

    // Be parametru
    public GeoLocation() {
        this(Math.random() * 180 - 90, Math.random() * 360 - 180);
    }

    // konstruktoriaus kopija
    public GeoLocation(GeoLocation location) {
        this(location.lat + (Math.random() * 0.2 - 0.1), location.lon + (Math.random() * 0.2 - 0.1));
    }

    // metodas spausdint koordinatems
    @Override
    public String toString() {
        return "[" + COORDINATE_FORMAT.format(lat) + ", " + COORDINATE_FORMAT.format(lon) + "]";
    }

    // metodas apskaiciuot atstuma
    public double distance(GeoLocation other) {
        double R = 6371; // Earth radius on average
        double dLat = Math.toRadians(other.lat - this.lat);
        double dLon = Math.toRadians(other.lon - this.lon);

        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(this.lat)) * Math.cos(Math.toRadians(other.lat)) *
                        Math.sin(dLon / 2) * Math.sin(dLon / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        return Math.round(R * c * 1e1) / 1e1;
    }

    // gauti rezultatai
    public static int getNumLocations() {
        return numLocations;
    }

    public static void main(String[] args) {
        GeoLocation someLocation = new GeoLocation();
        GeoLocation vilnius = new GeoLocation(54.683333, 25.283333);
        GeoLocation luxembourg = new GeoLocation(49.6117, 6.13);
        GeoLocation nearVilnius = new GeoLocation(vilnius);

        System.out.println(someLocation);
        System.out.println(vilnius);
        System.out.println(nearVilnius);

        System.out.println("Number of locations: " + GeoLocation.getNumLocations());

        System.out.println("From Vilnius to Luxembourg: " + vilnius.distance(luxembourg));
        System.out.println("From Vilnius to random location: " + vilnius.distance(someLocation));
        System.out.println("From Vilnius to random neighbor: " + vilnius.distance(nearVilnius));
    }
}
